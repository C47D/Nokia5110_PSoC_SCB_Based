/*******************************************************************************
* File Name: NOKIA5110_SCB_SPI_BOOT.h
* Version 3.20
*
* Description:
*  This file provides constants and parameter values of the bootloader
*  communication APIs for the SCB Component.
*
* Note:
*
********************************************************************************
* Copyright 2014-2016, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_BOOT_NOKIA5110_SCB_SPI_H)
#define CY_SCB_BOOT_NOKIA5110_SCB_SPI_H

#include "NOKIA5110_SCB_SPI_PVT.h"

#if (NOKIA5110_SCB_SPI_SCB_MODE_I2C_INC)
    #include "NOKIA5110_SCB_SPI_I2C.h"
#endif /* (NOKIA5110_SCB_SPI_SCB_MODE_I2C_INC) */

#if (NOKIA5110_SCB_SPI_SCB_MODE_EZI2C_INC)
    #include "NOKIA5110_SCB_SPI_EZI2C.h"
#endif /* (NOKIA5110_SCB_SPI_SCB_MODE_EZI2C_INC) */

#if (NOKIA5110_SCB_SPI_SCB_MODE_SPI_INC || NOKIA5110_SCB_SPI_SCB_MODE_UART_INC)
    #include "NOKIA5110_SCB_SPI_SPI_UART.h"
#endif /* (NOKIA5110_SCB_SPI_SCB_MODE_SPI_INC || NOKIA5110_SCB_SPI_SCB_MODE_UART_INC) */


/***************************************
*  Conditional Compilation Parameters
****************************************/

/* Bootloader communication interface enable */
#define NOKIA5110_SCB_SPI_BTLDR_COMM_ENABLED ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_NOKIA5110_SCB_SPI) || \
                                             (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))

/* Enable I2C bootloader communication */
#if (NOKIA5110_SCB_SPI_SCB_MODE_I2C_INC)
    #define NOKIA5110_SCB_SPI_I2C_BTLDR_COMM_ENABLED     (NOKIA5110_SCB_SPI_BTLDR_COMM_ENABLED && \
                                                            (NOKIA5110_SCB_SPI_SCB_MODE_UNCONFIG_CONST_CFG || \
                                                             NOKIA5110_SCB_SPI_I2C_SLAVE_CONST))
#else
     #define NOKIA5110_SCB_SPI_I2C_BTLDR_COMM_ENABLED    (0u)
#endif /* (NOKIA5110_SCB_SPI_SCB_MODE_I2C_INC) */

/* EZI2C does not support bootloader communication. Provide empty APIs */
#if (NOKIA5110_SCB_SPI_SCB_MODE_EZI2C_INC)
    #define NOKIA5110_SCB_SPI_EZI2C_BTLDR_COMM_ENABLED   (NOKIA5110_SCB_SPI_BTLDR_COMM_ENABLED && \
                                                         NOKIA5110_SCB_SPI_SCB_MODE_UNCONFIG_CONST_CFG)
#else
    #define NOKIA5110_SCB_SPI_EZI2C_BTLDR_COMM_ENABLED   (0u)
#endif /* (NOKIA5110_SCB_SPI_EZI2C_BTLDR_COMM_ENABLED) */

/* Enable SPI bootloader communication */
#if (NOKIA5110_SCB_SPI_SCB_MODE_SPI_INC)
    #define NOKIA5110_SCB_SPI_SPI_BTLDR_COMM_ENABLED     (NOKIA5110_SCB_SPI_BTLDR_COMM_ENABLED && \
                                                            (NOKIA5110_SCB_SPI_SCB_MODE_UNCONFIG_CONST_CFG || \
                                                             NOKIA5110_SCB_SPI_SPI_SLAVE_CONST))
#else
        #define NOKIA5110_SCB_SPI_SPI_BTLDR_COMM_ENABLED (0u)
#endif /* (NOKIA5110_SCB_SPI_SPI_BTLDR_COMM_ENABLED) */

/* Enable UART bootloader communication */
#if (NOKIA5110_SCB_SPI_SCB_MODE_UART_INC)
       #define NOKIA5110_SCB_SPI_UART_BTLDR_COMM_ENABLED    (NOKIA5110_SCB_SPI_BTLDR_COMM_ENABLED && \
                                                            (NOKIA5110_SCB_SPI_SCB_MODE_UNCONFIG_CONST_CFG || \
                                                             (NOKIA5110_SCB_SPI_UART_RX_DIRECTION && \
                                                              NOKIA5110_SCB_SPI_UART_TX_DIRECTION)))
#else
     #define NOKIA5110_SCB_SPI_UART_BTLDR_COMM_ENABLED   (0u)
#endif /* (NOKIA5110_SCB_SPI_UART_BTLDR_COMM_ENABLED) */

/* Enable bootloader communication */
#define NOKIA5110_SCB_SPI_BTLDR_COMM_MODE_ENABLED    (NOKIA5110_SCB_SPI_I2C_BTLDR_COMM_ENABLED   || \
                                                     NOKIA5110_SCB_SPI_SPI_BTLDR_COMM_ENABLED   || \
                                                     NOKIA5110_SCB_SPI_EZI2C_BTLDR_COMM_ENABLED || \
                                                     NOKIA5110_SCB_SPI_UART_BTLDR_COMM_ENABLED)


/***************************************
*        Function Prototypes
***************************************/

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (NOKIA5110_SCB_SPI_I2C_BTLDR_COMM_ENABLED)
    /* I2C Bootloader physical layer functions */
    void NOKIA5110_SCB_SPI_I2CCyBtldrCommStart(void);
    void NOKIA5110_SCB_SPI_I2CCyBtldrCommStop (void);
    void NOKIA5110_SCB_SPI_I2CCyBtldrCommReset(void);
    cystatus NOKIA5110_SCB_SPI_I2CCyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    cystatus NOKIA5110_SCB_SPI_I2CCyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);

    /* Map I2C specific bootloader communication APIs to SCB specific APIs */
    #if (NOKIA5110_SCB_SPI_SCB_MODE_I2C_CONST_CFG)
        #define NOKIA5110_SCB_SPI_CyBtldrCommStart   NOKIA5110_SCB_SPI_I2CCyBtldrCommStart
        #define NOKIA5110_SCB_SPI_CyBtldrCommStop    NOKIA5110_SCB_SPI_I2CCyBtldrCommStop
        #define NOKIA5110_SCB_SPI_CyBtldrCommReset   NOKIA5110_SCB_SPI_I2CCyBtldrCommReset
        #define NOKIA5110_SCB_SPI_CyBtldrCommRead    NOKIA5110_SCB_SPI_I2CCyBtldrCommRead
        #define NOKIA5110_SCB_SPI_CyBtldrCommWrite   NOKIA5110_SCB_SPI_I2CCyBtldrCommWrite
    #endif /* (NOKIA5110_SCB_SPI_SCB_MODE_I2C_CONST_CFG) */

#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (NOKIA5110_SCB_SPI_I2C_BTLDR_COMM_ENABLED) */


#if defined(CYDEV_BOOTLOADER_IO_COMP) && (NOKIA5110_SCB_SPI_EZI2C_BTLDR_COMM_ENABLED)
    /* Bootloader physical layer functions */
    void NOKIA5110_SCB_SPI_EzI2CCyBtldrCommStart(void);
    void NOKIA5110_SCB_SPI_EzI2CCyBtldrCommStop (void);
    void NOKIA5110_SCB_SPI_EzI2CCyBtldrCommReset(void);
    cystatus NOKIA5110_SCB_SPI_EzI2CCyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    cystatus NOKIA5110_SCB_SPI_EzI2CCyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);

    /* Map EZI2C specific bootloader communication APIs to SCB specific APIs */
    #if (NOKIA5110_SCB_SPI_SCB_MODE_EZI2C_CONST_CFG)
        #define NOKIA5110_SCB_SPI_CyBtldrCommStart   NOKIA5110_SCB_SPI_EzI2CCyBtldrCommStart
        #define NOKIA5110_SCB_SPI_CyBtldrCommStop    NOKIA5110_SCB_SPI_EzI2CCyBtldrCommStop
        #define NOKIA5110_SCB_SPI_CyBtldrCommReset   NOKIA5110_SCB_SPI_EzI2CCyBtldrCommReset
        #define NOKIA5110_SCB_SPI_CyBtldrCommRead    NOKIA5110_SCB_SPI_EzI2CCyBtldrCommRead
        #define NOKIA5110_SCB_SPI_CyBtldrCommWrite   NOKIA5110_SCB_SPI_EzI2CCyBtldrCommWrite
    #endif /* (NOKIA5110_SCB_SPI_SCB_MODE_EZI2C_CONST_CFG) */

#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (NOKIA5110_SCB_SPI_EZI2C_BTLDR_COMM_ENABLED) */

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (NOKIA5110_SCB_SPI_SPI_BTLDR_COMM_ENABLED)
    /* SPI Bootloader physical layer functions */
    void NOKIA5110_SCB_SPI_SpiCyBtldrCommStart(void);
    void NOKIA5110_SCB_SPI_SpiCyBtldrCommStop (void);
    void NOKIA5110_SCB_SPI_SpiCyBtldrCommReset(void);
    cystatus NOKIA5110_SCB_SPI_SpiCyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    cystatus NOKIA5110_SCB_SPI_SpiCyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);

    /* Map SPI specific bootloader communication APIs to SCB specific APIs */
    #if (NOKIA5110_SCB_SPI_SCB_MODE_SPI_CONST_CFG)
        #define NOKIA5110_SCB_SPI_CyBtldrCommStart   NOKIA5110_SCB_SPI_SpiCyBtldrCommStart
        #define NOKIA5110_SCB_SPI_CyBtldrCommStop    NOKIA5110_SCB_SPI_SpiCyBtldrCommStop
        #define NOKIA5110_SCB_SPI_CyBtldrCommReset   NOKIA5110_SCB_SPI_SpiCyBtldrCommReset
        #define NOKIA5110_SCB_SPI_CyBtldrCommRead    NOKIA5110_SCB_SPI_SpiCyBtldrCommRead
        #define NOKIA5110_SCB_SPI_CyBtldrCommWrite   NOKIA5110_SCB_SPI_SpiCyBtldrCommWrite
    #endif /* (NOKIA5110_SCB_SPI_SCB_MODE_SPI_CONST_CFG) */

#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (NOKIA5110_SCB_SPI_SPI_BTLDR_COMM_ENABLED) */

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (NOKIA5110_SCB_SPI_UART_BTLDR_COMM_ENABLED)
    /* UART Bootloader physical layer functions */
    void NOKIA5110_SCB_SPI_UartCyBtldrCommStart(void);
    void NOKIA5110_SCB_SPI_UartCyBtldrCommStop (void);
    void NOKIA5110_SCB_SPI_UartCyBtldrCommReset(void);
    cystatus NOKIA5110_SCB_SPI_UartCyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    cystatus NOKIA5110_SCB_SPI_UartCyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);

    /* Map UART specific bootloader communication APIs to SCB specific APIs */
    #if (NOKIA5110_SCB_SPI_SCB_MODE_UART_CONST_CFG)
        #define NOKIA5110_SCB_SPI_CyBtldrCommStart   NOKIA5110_SCB_SPI_UartCyBtldrCommStart
        #define NOKIA5110_SCB_SPI_CyBtldrCommStop    NOKIA5110_SCB_SPI_UartCyBtldrCommStop
        #define NOKIA5110_SCB_SPI_CyBtldrCommReset   NOKIA5110_SCB_SPI_UartCyBtldrCommReset
        #define NOKIA5110_SCB_SPI_CyBtldrCommRead    NOKIA5110_SCB_SPI_UartCyBtldrCommRead
        #define NOKIA5110_SCB_SPI_CyBtldrCommWrite   NOKIA5110_SCB_SPI_UartCyBtldrCommWrite
    #endif /* (NOKIA5110_SCB_SPI_SCB_MODE_UART_CONST_CFG) */

#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (NOKIA5110_SCB_SPI_UART_BTLDR_COMM_ENABLED) */

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (NOKIA5110_SCB_SPI_BTLDR_COMM_ENABLED)
    #if (NOKIA5110_SCB_SPI_SCB_MODE_UNCONFIG_CONST_CFG)
        /* Bootloader physical layer functions */
        void NOKIA5110_SCB_SPI_CyBtldrCommStart(void);
        void NOKIA5110_SCB_SPI_CyBtldrCommStop (void);
        void NOKIA5110_SCB_SPI_CyBtldrCommReset(void);
        cystatus NOKIA5110_SCB_SPI_CyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
        cystatus NOKIA5110_SCB_SPI_CyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    #endif /* (NOKIA5110_SCB_SPI_SCB_MODE_UNCONFIG_CONST_CFG) */

    /* Map SCB specific bootloader communication APIs to common APIs */
    #if (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_NOKIA5110_SCB_SPI)
        #define CyBtldrCommStart    NOKIA5110_SCB_SPI_CyBtldrCommStart
        #define CyBtldrCommStop     NOKIA5110_SCB_SPI_CyBtldrCommStop
        #define CyBtldrCommReset    NOKIA5110_SCB_SPI_CyBtldrCommReset
        #define CyBtldrCommWrite    NOKIA5110_SCB_SPI_CyBtldrCommWrite
        #define CyBtldrCommRead     NOKIA5110_SCB_SPI_CyBtldrCommRead
    #endif /* (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_NOKIA5110_SCB_SPI) */

#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (NOKIA5110_SCB_SPI_BTLDR_COMM_ENABLED) */


/***************************************
*           API Constants
***************************************/

/* Timeout unit in milliseconds */
#define NOKIA5110_SCB_SPI_WAIT_1_MS  (1u)

/* Return number of bytes to copy into bootloader buffer */
#define NOKIA5110_SCB_SPI_BYTES_TO_COPY(actBufSize, bufSize) \
                            ( ((uint32)(actBufSize) < (uint32)(bufSize)) ? \
                                ((uint32) (actBufSize)) : ((uint32) (bufSize)) )

/* Size of Read/Write buffers for I2C bootloader  */
#define NOKIA5110_SCB_SPI_I2C_BTLDR_SIZEOF_READ_BUFFER   (64u)
#define NOKIA5110_SCB_SPI_I2C_BTLDR_SIZEOF_WRITE_BUFFER  (64u)

/* Byte to byte time interval: calculated basing on current component
* data rate configuration, can be defined in project if required.
*/
#ifndef NOKIA5110_SCB_SPI_SPI_BYTE_TO_BYTE
    #define NOKIA5110_SCB_SPI_SPI_BYTE_TO_BYTE   (6u)
#endif

/* Byte to byte time interval: calculated basing on current component
* baud rate configuration, can be defined in the project if required.
*/
#ifndef NOKIA5110_SCB_SPI_UART_BYTE_TO_BYTE
    #define NOKIA5110_SCB_SPI_UART_BYTE_TO_BYTE  (2500u)
#endif /* NOKIA5110_SCB_SPI_UART_BYTE_TO_BYTE */

#endif /* (CY_SCB_BOOT_NOKIA5110_SCB_SPI_H) */


/* [] END OF FILE */
