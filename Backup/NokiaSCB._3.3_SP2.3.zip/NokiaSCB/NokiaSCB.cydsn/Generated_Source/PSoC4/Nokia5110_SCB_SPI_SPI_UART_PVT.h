/*******************************************************************************
* File Name: NOKIA5110_SCB_SPI_SPI_UART_PVT.h
* Version 3.20
*
* Description:
*  This private file provides constants and parameter values for the
*  SCB Component in SPI and UART modes.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* Copyright 2013-2016, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_SPI_UART_PVT_NOKIA5110_SCB_SPI_H)
#define CY_SCB_SPI_UART_PVT_NOKIA5110_SCB_SPI_H

#include "NOKIA5110_SCB_SPI_SPI_UART.h"


/***************************************
*     Internal Global Vars
***************************************/

#if (NOKIA5110_SCB_SPI_INTERNAL_RX_SW_BUFFER_CONST)
    extern volatile uint32  NOKIA5110_SCB_SPI_rxBufferHead;
    extern volatile uint32  NOKIA5110_SCB_SPI_rxBufferTail;
    extern volatile uint8   NOKIA5110_SCB_SPI_rxBufferOverflow;
#endif /* (NOKIA5110_SCB_SPI_INTERNAL_RX_SW_BUFFER_CONST) */

#if (NOKIA5110_SCB_SPI_INTERNAL_TX_SW_BUFFER_CONST)
    extern volatile uint32  NOKIA5110_SCB_SPI_txBufferHead;
    extern volatile uint32  NOKIA5110_SCB_SPI_txBufferTail;
#endif /* (NOKIA5110_SCB_SPI_INTERNAL_TX_SW_BUFFER_CONST) */

#if (NOKIA5110_SCB_SPI_INTERNAL_RX_SW_BUFFER)
    extern volatile uint8 NOKIA5110_SCB_SPI_rxBufferInternal[NOKIA5110_SCB_SPI_INTERNAL_RX_BUFFER_SIZE];
#endif /* (NOKIA5110_SCB_SPI_INTERNAL_RX_SW_BUFFER) */

#if (NOKIA5110_SCB_SPI_INTERNAL_TX_SW_BUFFER)
    extern volatile uint8 NOKIA5110_SCB_SPI_txBufferInternal[NOKIA5110_SCB_SPI_TX_BUFFER_SIZE];
#endif /* (NOKIA5110_SCB_SPI_INTERNAL_TX_SW_BUFFER) */


/***************************************
*     Private Function Prototypes
***************************************/

void NOKIA5110_SCB_SPI_SpiPostEnable(void);
void NOKIA5110_SCB_SPI_SpiStop(void);

#if (NOKIA5110_SCB_SPI_SCB_MODE_SPI_CONST_CFG)
    void NOKIA5110_SCB_SPI_SpiInit(void);
#endif /* (NOKIA5110_SCB_SPI_SCB_MODE_SPI_CONST_CFG) */

#if (NOKIA5110_SCB_SPI_SPI_WAKE_ENABLE_CONST)
    void NOKIA5110_SCB_SPI_SpiSaveConfig(void);
    void NOKIA5110_SCB_SPI_SpiRestoreConfig(void);
#endif /* (NOKIA5110_SCB_SPI_SPI_WAKE_ENABLE_CONST) */

void NOKIA5110_SCB_SPI_UartPostEnable(void);
void NOKIA5110_SCB_SPI_UartStop(void);

#if (NOKIA5110_SCB_SPI_SCB_MODE_UART_CONST_CFG)
    void NOKIA5110_SCB_SPI_UartInit(void);
#endif /* (NOKIA5110_SCB_SPI_SCB_MODE_UART_CONST_CFG) */

#if (NOKIA5110_SCB_SPI_UART_WAKE_ENABLE_CONST)
    void NOKIA5110_SCB_SPI_UartSaveConfig(void);
    void NOKIA5110_SCB_SPI_UartRestoreConfig(void);
#endif /* (NOKIA5110_SCB_SPI_UART_WAKE_ENABLE_CONST) */


/***************************************
*         UART API Constants
***************************************/

/* UART RX and TX position to be used in NOKIA5110_SCB_SPI_SetPins() */
#define NOKIA5110_SCB_SPI_UART_RX_PIN_ENABLE    (NOKIA5110_SCB_SPI_UART_RX)
#define NOKIA5110_SCB_SPI_UART_TX_PIN_ENABLE    (NOKIA5110_SCB_SPI_UART_TX)

/* UART RTS and CTS position to be used in  NOKIA5110_SCB_SPI_SetPins() */
#define NOKIA5110_SCB_SPI_UART_RTS_PIN_ENABLE    (0x10u)
#define NOKIA5110_SCB_SPI_UART_CTS_PIN_ENABLE    (0x20u)


/***************************************
* The following code is DEPRECATED and
* must not be used.
***************************************/

/* Interrupt processing */
#define NOKIA5110_SCB_SPI_SpiUartEnableIntRx(intSourceMask)  NOKIA5110_SCB_SPI_SetRxInterruptMode(intSourceMask)
#define NOKIA5110_SCB_SPI_SpiUartEnableIntTx(intSourceMask)  NOKIA5110_SCB_SPI_SetTxInterruptMode(intSourceMask)
uint32  NOKIA5110_SCB_SPI_SpiUartDisableIntRx(void);
uint32  NOKIA5110_SCB_SPI_SpiUartDisableIntTx(void);


#endif /* (CY_SCB_SPI_UART_PVT_NOKIA5110_SCB_SPI_H) */


/* [] END OF FILE */
