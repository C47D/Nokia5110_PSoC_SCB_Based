/*******************************************************************************
* File Name: NOKIA5110_SCB_Clk.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_NOKIA5110_SCB_Clk_H)
#define CY_CLOCK_NOKIA5110_SCB_Clk_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
*        Function Prototypes
***************************************/
#if defined CYREG_PERI_DIV_CMD

void NOKIA5110_SCB_Clk_StartEx(uint32 alignClkDiv);
#define NOKIA5110_SCB_Clk_Start() \
    NOKIA5110_SCB_Clk_StartEx(NOKIA5110_SCB_Clk__PA_DIV_ID)

#else

void NOKIA5110_SCB_Clk_Start(void);

#endif/* CYREG_PERI_DIV_CMD */

void NOKIA5110_SCB_Clk_Stop(void);

void NOKIA5110_SCB_Clk_SetFractionalDividerRegister(uint16 clkDivider, uint8 clkFractional);

uint16 NOKIA5110_SCB_Clk_GetDividerRegister(void);
uint8  NOKIA5110_SCB_Clk_GetFractionalDividerRegister(void);

#define NOKIA5110_SCB_Clk_Enable()                         NOKIA5110_SCB_Clk_Start()
#define NOKIA5110_SCB_Clk_Disable()                        NOKIA5110_SCB_Clk_Stop()
#define NOKIA5110_SCB_Clk_SetDividerRegister(clkDivider, reset)  \
    NOKIA5110_SCB_Clk_SetFractionalDividerRegister((clkDivider), 0u)
#define NOKIA5110_SCB_Clk_SetDivider(clkDivider)           NOKIA5110_SCB_Clk_SetDividerRegister((clkDivider), 1u)
#define NOKIA5110_SCB_Clk_SetDividerValue(clkDivider)      NOKIA5110_SCB_Clk_SetDividerRegister((clkDivider) - 1u, 1u)


/***************************************
*             Registers
***************************************/
#if defined CYREG_PERI_DIV_CMD

#define NOKIA5110_SCB_Clk_DIV_ID     NOKIA5110_SCB_Clk__DIV_ID

#define NOKIA5110_SCB_Clk_CMD_REG    (*(reg32 *)CYREG_PERI_DIV_CMD)
#define NOKIA5110_SCB_Clk_CTRL_REG   (*(reg32 *)NOKIA5110_SCB_Clk__CTRL_REGISTER)
#define NOKIA5110_SCB_Clk_DIV_REG    (*(reg32 *)NOKIA5110_SCB_Clk__DIV_REGISTER)

#define NOKIA5110_SCB_Clk_CMD_DIV_SHIFT          (0u)
#define NOKIA5110_SCB_Clk_CMD_PA_DIV_SHIFT       (8u)
#define NOKIA5110_SCB_Clk_CMD_DISABLE_SHIFT      (30u)
#define NOKIA5110_SCB_Clk_CMD_ENABLE_SHIFT       (31u)

#define NOKIA5110_SCB_Clk_CMD_DISABLE_MASK       ((uint32)((uint32)1u << NOKIA5110_SCB_Clk_CMD_DISABLE_SHIFT))
#define NOKIA5110_SCB_Clk_CMD_ENABLE_MASK        ((uint32)((uint32)1u << NOKIA5110_SCB_Clk_CMD_ENABLE_SHIFT))

#define NOKIA5110_SCB_Clk_DIV_FRAC_MASK  (0x000000F8u)
#define NOKIA5110_SCB_Clk_DIV_FRAC_SHIFT (3u)
#define NOKIA5110_SCB_Clk_DIV_INT_MASK   (0xFFFFFF00u)
#define NOKIA5110_SCB_Clk_DIV_INT_SHIFT  (8u)

#else 

#define NOKIA5110_SCB_Clk_DIV_REG        (*(reg32 *)NOKIA5110_SCB_Clk__REGISTER)
#define NOKIA5110_SCB_Clk_ENABLE_REG     NOKIA5110_SCB_Clk_DIV_REG
#define NOKIA5110_SCB_Clk_DIV_FRAC_MASK  NOKIA5110_SCB_Clk__FRAC_MASK
#define NOKIA5110_SCB_Clk_DIV_FRAC_SHIFT (16u)
#define NOKIA5110_SCB_Clk_DIV_INT_MASK   NOKIA5110_SCB_Clk__DIVIDER_MASK
#define NOKIA5110_SCB_Clk_DIV_INT_SHIFT  (0u)

#endif/* CYREG_PERI_DIV_CMD */

#endif /* !defined(CY_CLOCK_NOKIA5110_SCB_Clk_H) */

/* [] END OF FILE */
